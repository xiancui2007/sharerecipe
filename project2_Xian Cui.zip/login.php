<?php    // login.php
$hn = 'localhost';
$db = '6205mydb';
$un = 'root';
$pw = 'RJvJiJNVruP4';
?>
